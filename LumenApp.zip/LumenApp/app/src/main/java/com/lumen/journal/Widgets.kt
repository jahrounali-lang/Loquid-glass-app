package com.lumen.journal

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

object Widgets {
    private const val P = "lumen"
    fun note(c: Context): Pair<String, String> {
        val s = c.getSharedPreferences(P, 0)
        return (s.getString("title", null) ?: "Lumen Journal") to
            (s.getString("text", null) ?: "The details are not the details. They make the design.")
    }
    fun saveNote(c: Context, t: String, x: String) {
        c.getSharedPreferences(P, 0).edit().putString("title", t.ifBlank { "Lumen Journal" }).putString("text", x).apply()
        val m = AppWidgetManager.getInstance(c)
        m.getAppWidgetIds(ComponentName(c, NoteWidget::class.java)).forEach { m.updateAppWidget(it, NoteWidget.build(c)) }
    }
    fun open(c: Context, page: String?, code: Int): PendingIntent {
        val i = Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (page != null) i.putExtra("page", page)
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}

class NoteWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { m.updateAppWidget(it, build(c)) }
    }
    companion object {
        fun build(c: Context): RemoteViews {
            val (t, x) = Widgets.note(c)
            return RemoteViews(c.packageName, R.layout.widget_note).apply {
                setTextViewText(R.id.w_title, t)
                setTextViewText(R.id.w_text, x)
                setOnClickPendingIntent(R.id.w_root, Widgets.open(c, null, 0))
            }
        }
    }
}

class QuickWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        val v = RemoteViews(c.packageName, R.layout.widget_quick)
        listOf(R.id.q_home to "home", R.id.q_reels to "reels", R.id.q_msg to "messages", R.id.q_search to "search")
            .forEachIndexed { i, (id, page) -> v.setOnClickPendingIntent(id, Widgets.open(c, page, 10 + i)) }
        ids.forEach { m.updateAppWidget(it, v) }
    }
}
