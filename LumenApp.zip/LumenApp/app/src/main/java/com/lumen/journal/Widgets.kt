package com.lumen.journal

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

object Widgets {
    private const val P = "lumen"
    fun note(c: Context): Pair<String, String> {
        val s = c.getSharedPreferences(P, 0)
        return (s.getString("title", null) ?: "Lumen Journal") to
            (s.getString("text", null) ?: "The details are not the details. They make the design.")
    }
    private val quotes = listOf(
        "The art of noticing" to "Finding fresh perspective in familiar places, one quiet detail at a time.",
        "Chasing golden hour" to "Why the last light of the day always feels different.",
        "Less, but better" to "Making room for the things that matter most.",
        "Into the quiet" to "A visual journey through the calm of the forest.",
        "Blue horizons" to "Open water, open thoughts, and a little perspective."
    )
    fun all(c: Context): List<Pair<String, String>> = listOf(note(c)) + quotes
    fun index(c: Context): Int = c.getSharedPreferences(P, 0).getInt("idx", 0) % all(c).size
    fun step(c: Context, d: Int) {
        val n = all(c).size
        c.getSharedPreferences(P, 0).edit().putInt("idx", (index(c) + d + n) % n).apply()
        refresh(c)
    }
    fun refresh(c: Context) {
        val m = AppWidgetManager.getInstance(c)
        m.getAppWidgetIds(ComponentName(c, NoteWidget::class.java)).forEach { m.updateAppWidget(it, NoteWidget.build(c)) }
    }
    fun saveNote(c: Context, t: String, x: String) {
        c.getSharedPreferences(P, 0).edit().putString("title", t.ifBlank { "Lumen Journal" }).putString("text", x).putInt("idx", 0).apply()
        refresh(c)
    }
    fun open(c: Context, page: String?, code: Int): PendingIntent {
        val i = Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (page != null) i.putExtra("page", page)
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}

class NoteWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { m.updateAppWidget(it, build(c)) }
    }
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            NEXT -> Widgets.step(c, 1)
            PREV -> Widgets.step(c, -1)
            else -> super.onReceive(c, i)
        }
    }
    companion object {
        const val NEXT = "com.lumen.journal.NEXT"
        const val PREV = "com.lumen.journal.PREV"
        private fun tap(c: Context, action: String, code: Int) = PendingIntent.getBroadcast(
            c, code, Intent(c, NoteWidget::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        fun build(c: Context): RemoteViews {
            val (t, x) = Widgets.all(c)[Widgets.index(c)]
            return RemoteViews(c.packageName, R.layout.widget_note).apply {
                setTextViewText(R.id.w_title, t)
                setTextViewText(R.id.w_text, x)
                setOnClickPendingIntent(R.id.w_root, Widgets.open(c, null, 0))
                setOnClickPendingIntent(R.id.w_next, tap(c, NEXT, 1))
                setOnClickPendingIntent(R.id.w_prev, tap(c, PREV, 2))
            }
        }
    }
}

class QuickWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        val v = RemoteViews(c.packageName, R.layout.widget_quick)
        listOf(R.id.q_home to "home", R.id.q_reels to "reels", R.id.q_msg to "messages", R.id.q_search to "search")
            .forEachIndexed { i, (id, page) -> v.setOnClickPendingIntent(id, Widgets.open(c, page, 10 + i)) }
        ids.forEach { m.updateAppWidget(it, v) }
    }
}
