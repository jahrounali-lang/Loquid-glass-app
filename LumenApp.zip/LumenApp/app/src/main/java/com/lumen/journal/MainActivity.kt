package com.lumen.journal

import android.annotation.SuppressLint
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.webkit.*
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pendingPage: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pendingPage = intent.getStringExtra("page")
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(applicationContext), "AndroidWidgets")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String) { openPending() }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        pendingPage = i.getStringExtra("page")
        openPending()
    }

    private fun openPending() {
        val p = pendingPage ?: return
        pendingPage = null
        web.evaluateJavascript("window.lumenNavigate&&lumenNavigate('$p')", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    class Bridge(private val ctx: Context) {
        @JavascriptInterface fun getNote(): String {
            val n = Widgets.note(ctx)
            return JSONObject().put("title", n.first).put("text", n.second).toString()
        }
        @JavascriptInterface fun setNote(title: String, text: String) {
            Widgets.saveNote(ctx, title, text)
        }
        @JavascriptInterface fun pinWidget(kind: String): Boolean {
            val m = AppWidgetManager.getInstance(ctx)
            if (!m.isRequestPinAppWidgetSupported) return false
            val cls = if (kind == "quick") QuickWidget::class.java else NoteWidget::class.java
            return m.requestPinAppWidget(ComponentName(ctx, cls), null, null)
        }
    }
}
