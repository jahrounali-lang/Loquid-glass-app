Open this folder in Android Studio -> wait for Gradle sync -> Build > Build APK(s).
Then on the phone: long-press home screen > Widgets > Lumen, or use the Widgets panel in the Profile tab.
Edit your page in app/src/main/assets/index.html
